--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.video DROP CONSTRAINT video_project_id_fkey;
ALTER TABLE ONLY public.video DROP CONSTRAINT video_meta_association_id_fkey;
ALTER TABLE ONLY public.tags DROP CONSTRAINT tags_tag_id_fkey;
ALTER TABLE ONLY public.tags DROP CONSTRAINT tags_project_id_fkey;
ALTER TABLE ONLY public.tag DROP CONSTRAINT tag_meta_association_id_fkey;
ALTER TABLE ONLY public.step DROP CONSTRAINT step_project_id_fkey;
ALTER TABLE ONLY public.step DROP CONSTRAINT step_meta_association_id_fkey;
ALTER TABLE ONLY public.step DROP CONSTRAINT step_chapter_id_fkey;
ALTER TABLE ONLY public.resource DROP CONSTRAINT resource_step_id_fkey;
ALTER TABLE ONLY public.resource DROP CONSTRAINT resource_project_id_fkey;
ALTER TABLE ONLY public.resource DROP CONSTRAINT resource_meta_association_id_fkey;
ALTER TABLE ONLY public.related_projects DROP CONSTRAINT related_projects_related_project_id_fkey;
ALTER TABLE ONLY public.related_projects DROP CONSTRAINT related_projects_project_id_fkey;
ALTER TABLE ONLY public.project DROP CONSTRAINT project_meta_association_id_fkey;
ALTER TABLE ONLY public.project DROP CONSTRAINT project_maker_id_fkey;
ALTER TABLE ONLY public.product DROP CONSTRAINT product_meta_association_id_fkey;
ALTER TABLE ONLY public.product DROP CONSTRAINT product_item_id_fkey;
ALTER TABLE ONLY public.page DROP CONSTRAINT page_meta_association_id_fkey;
ALTER TABLE ONLY public.meta DROP CONSTRAINT meta_association_id_fkey;
ALTER TABLE ONLY public.maker DROP CONSTRAINT maker_meta_association_id_fkey;
ALTER TABLE ONLY public.item DROP CONSTRAINT item_meta_association_id_fkey;
ALTER TABLE ONLY public.guru DROP CONSTRAINT guru_meta_association_id_fkey;
ALTER TABLE ONLY public.component DROP CONSTRAINT component_step_id_fkey;
ALTER TABLE ONLY public.component DROP CONSTRAINT component_project_id_fkey;
ALTER TABLE ONLY public.component DROP CONSTRAINT component_meta_association_id_fkey;
ALTER TABLE ONLY public.component DROP CONSTRAINT component_item_id_fkey;
ALTER TABLE ONLY public.chapter DROP CONSTRAINT chapter_video_id_fkey;
ALTER TABLE ONLY public.chapter DROP CONSTRAINT chapter_meta_association_id_fkey;
ALTER TABLE ONLY public.video DROP CONSTRAINT video_pkey;
ALTER TABLE ONLY public.video DROP CONSTRAINT video_path_key;
ALTER TABLE ONLY public.video DROP CONSTRAINT video_name_key;
ALTER TABLE ONLY public.video DROP CONSTRAINT video_host_guid_key;
ALTER TABLE ONLY public.tag DROP CONSTRAINT tag_pkey;
ALTER TABLE ONLY public.tag DROP CONSTRAINT tag_name_key;
ALTER TABLE ONLY public.step DROP CONSTRAINT step_title_key;
ALTER TABLE ONLY public.step DROP CONSTRAINT step_pkey;
ALTER TABLE ONLY public.resource DROP CONSTRAINT resource_pkey;
ALTER TABLE ONLY public.resource DROP CONSTRAINT resource_path_key;
ALTER TABLE ONLY public.project DROP CONSTRAINT project_title_key;
ALTER TABLE ONLY public.project DROP CONSTRAINT project_slug_key;
ALTER TABLE ONLY public.project DROP CONSTRAINT project_pkey;
ALTER TABLE ONLY public.product DROP CONSTRAINT product_pkey;
ALTER TABLE ONLY public.product DROP CONSTRAINT product_name_key;
ALTER TABLE ONLY public.page DROP CONSTRAINT page_slug_key;
ALTER TABLE ONLY public.page DROP CONSTRAINT page_pkey;
ALTER TABLE ONLY public.meta DROP CONSTRAINT meta_pkey;
ALTER TABLE ONLY public.meta_association DROP CONSTRAINT meta_association_pkey;
ALTER TABLE ONLY public.maker DROP CONSTRAINT maker_pkey;
ALTER TABLE ONLY public.maker DROP CONSTRAINT maker_nickname_key;
ALTER TABLE ONLY public.maker DROP CONSTRAINT maker_email_key;
ALTER TABLE ONLY public.item DROP CONSTRAINT item_pkey;
ALTER TABLE ONLY public.item DROP CONSTRAINT item_name_key;
ALTER TABLE ONLY public.guru DROP CONSTRAINT guru_pkey;
ALTER TABLE ONLY public.guru DROP CONSTRAINT guru_name_key;
ALTER TABLE ONLY public.guru DROP CONSTRAINT guru_alias_key;
ALTER TABLE ONLY public.component DROP CONSTRAINT component_pkey;
ALTER TABLE ONLY public.chapter DROP CONSTRAINT chapter_title_key;
ALTER TABLE ONLY public.chapter DROP CONSTRAINT chapter_pkey;
ALTER TABLE public.video ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tag ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.step ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.resource ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.project ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.product ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.page ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.meta_association ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.meta ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.maker ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.item ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.guru ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.component ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.chapter ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.video_id_seq;
DROP TABLE public.video;
DROP TABLE public.tags;
DROP SEQUENCE public.tag_id_seq;
DROP TABLE public.tag;
DROP SEQUENCE public.step_id_seq;
DROP TABLE public.step;
DROP SEQUENCE public.resource_id_seq;
DROP TABLE public.resource;
DROP TABLE public.related_projects;
DROP SEQUENCE public.project_id_seq;
DROP TABLE public.project;
DROP SEQUENCE public.product_id_seq;
DROP TABLE public.product;
DROP SEQUENCE public.page_id_seq;
DROP TABLE public.page;
DROP SEQUENCE public.meta_id_seq;
DROP SEQUENCE public.meta_association_id_seq;
DROP TABLE public.meta_association;
DROP TABLE public.meta;
DROP SEQUENCE public.maker_id_seq;
DROP TABLE public.maker;
DROP SEQUENCE public.item_id_seq;
DROP TABLE public.item;
DROP SEQUENCE public.guru_id_seq;
DROP TABLE public.guru;
DROP SEQUENCE public.component_id_seq;
DROP TABLE public.component;
DROP SEQUENCE public.chapter_id_seq;
DROP TABLE public.chapter;
DROP EXTENSION hstore;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: chapter; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE chapter (
    created_on timestamp without time zone,
    updated_on timestamp without time zone,
    id integer NOT NULL,
    video_id integer,
    title character varying(80),
    start_time integer,
    duration integer,
    "order" integer,
    meta_association_id integer
);


--
-- Name: chapter_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE chapter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: chapter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE chapter_id_seq OWNED BY chapter.id;


--
-- Name: component; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE component (
    created_on timestamp without time zone,
    updated_on timestamp without time zone,
    id integer NOT NULL,
    step_id integer,
    project_id integer,
    item_id integer,
    quantity integer,
    note character varying(255),
    required boolean,
    meta_association_id integer
);


--
-- Name: component_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE component_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: component_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE component_id_seq OWNED BY component.id;


--
-- Name: guru; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE guru (
    created_on timestamp without time zone,
    updated_on timestamp without time zone,
    id integer NOT NULL,
    youtube_channel_url character varying(512),
    facebook_url character varying(512),
    twitter_handle character varying(40),
    email character varying(40),
    name character varying(80),
    alias character varying(80),
    description character varying(512),
    logo_url character varying(512),
    headshot_url character varying(512),
    meta_association_id integer
);


--
-- Name: guru_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE guru_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: guru_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE guru_id_seq OWNED BY guru.id;


--
-- Name: item; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE item (
    created_on timestamp without time zone,
    updated_on timestamp without time zone,
    id integer NOT NULL,
    name character varying(80),
    description character varying(255),
    note character varying(255),
    meta_association_id integer
);


--
-- Name: item_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE item_id_seq OWNED BY item.id;


--
-- Name: maker; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE maker (
    created_on timestamp without time zone,
    updated_on timestamp without time zone,
    id integer NOT NULL,
    nickname character varying(64),
    email character varying(120),
    role smallint,
    meta_association_id integer
);


--
-- Name: maker_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE maker_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: maker_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE maker_id_seq OWNED BY maker.id;


--
-- Name: meta; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE meta (
    created_on timestamp without time zone,
    updated_on timestamp without time zone,
    id integer NOT NULL,
    data hstore,
    association_id integer
);


--
-- Name: meta_association; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE meta_association (
    created_on timestamp without time zone,
    updated_on timestamp without time zone,
    id integer NOT NULL,
    discriminator character varying
);


--
-- Name: meta_association_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE meta_association_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meta_association_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE meta_association_id_seq OWNED BY meta_association.id;


--
-- Name: meta_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE meta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE meta_id_seq OWNED BY meta.id;


--
-- Name: page; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE page (
    created_on timestamp without time zone,
    updated_on timestamp without time zone,
    id integer NOT NULL,
    slug character varying(80),
    title character varying(80),
    html text,
    meta_association_id integer
);


--
-- Name: page_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE page_id_seq OWNED BY page.id;


--
-- Name: product; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE product (
    created_on timestamp without time zone,
    updated_on timestamp without time zone,
    id integer NOT NULL,
    name character varying(80),
    description character varying(255),
    item_id integer,
    price double precision,
    shop_url character varying(512),
    meta_association_id integer
);


--
-- Name: product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE product_id_seq OWNED BY product.id;


--
-- Name: project; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE project (
    created_on timestamp without time zone,
    updated_on timestamp without time zone,
    id integer NOT NULL,
    title character varying(160),
    description text,
    full_description text,
    maker_id integer,
    slug character varying(80),
    meta_association_id integer
);


--
-- Name: project_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE project_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE project_id_seq OWNED BY project.id;


--
-- Name: related_projects; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE related_projects (
    project_id integer,
    related_project_id integer
);


--
-- Name: resource; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE resource (
    created_on timestamp without time zone,
    updated_on timestamp without time zone,
    id integer NOT NULL,
    project_id integer,
    step_id integer,
    name character varying(80),
    path character varying(80),
    meta_association_id integer
);


--
-- Name: resource_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE resource_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: resource_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE resource_id_seq OWNED BY resource.id;


--
-- Name: step; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE step (
    created_on timestamp without time zone,
    updated_on timestamp without time zone,
    id integer NOT NULL,
    title character varying(80),
    start_time integer,
    description character varying(255),
    "order" integer,
    project_id integer,
    chapter_id integer,
    meta_association_id integer
);


--
-- Name: step_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE step_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: step_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE step_id_seq OWNED BY step.id;


--
-- Name: tag; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE tag (
    created_on timestamp without time zone,
    updated_on timestamp without time zone,
    id integer NOT NULL,
    name character varying(80),
    meta_association_id integer
);


--
-- Name: tag_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE tag_id_seq OWNED BY tag.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE tags (
    tag_id integer,
    project_id integer
);


--
-- Name: video; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE video (
    created_on timestamp without time zone,
    updated_on timestamp without time zone,
    id integer NOT NULL,
    posted_on timestamp without time zone,
    project_id integer,
    name character varying(140),
    host_guid character varying(80),
    path character varying(80),
    meta_association_id integer
);


--
-- Name: video_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE video_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: video_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE video_id_seq OWNED BY video.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY chapter ALTER COLUMN id SET DEFAULT nextval('chapter_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY component ALTER COLUMN id SET DEFAULT nextval('component_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY guru ALTER COLUMN id SET DEFAULT nextval('guru_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY item ALTER COLUMN id SET DEFAULT nextval('item_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY maker ALTER COLUMN id SET DEFAULT nextval('maker_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY meta ALTER COLUMN id SET DEFAULT nextval('meta_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY meta_association ALTER COLUMN id SET DEFAULT nextval('meta_association_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY page ALTER COLUMN id SET DEFAULT nextval('page_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY product ALTER COLUMN id SET DEFAULT nextval('product_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY project ALTER COLUMN id SET DEFAULT nextval('project_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY resource ALTER COLUMN id SET DEFAULT nextval('resource_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY step ALTER COLUMN id SET DEFAULT nextval('step_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY tag ALTER COLUMN id SET DEFAULT nextval('tag_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY video ALTER COLUMN id SET DEFAULT nextval('video_id_seq'::regclass);


--
-- Data for Name: chapter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY chapter (created_on, updated_on, id, video_id, title, start_time, duration, "order", meta_association_id) FROM stdin;
\.
COPY chapter (created_on, updated_on, id, video_id, title, start_time, duration, "order", meta_association_id) FROM '$$PATH$$/2510.dat';

--
-- Name: chapter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('chapter_id_seq', 1, false);


--
-- Data for Name: component; Type: TABLE DATA; Schema: public; Owner: -
--

COPY component (created_on, updated_on, id, step_id, project_id, item_id, quantity, note, required, meta_association_id) FROM stdin;
\.
COPY component (created_on, updated_on, id, step_id, project_id, item_id, quantity, note, required, meta_association_id) FROM '$$PATH$$/2514.dat';

--
-- Name: component_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('component_id_seq', 1, false);


--
-- Data for Name: guru; Type: TABLE DATA; Schema: public; Owner: -
--

COPY guru (created_on, updated_on, id, youtube_channel_url, facebook_url, twitter_handle, email, name, alias, description, logo_url, headshot_url, meta_association_id) FROM stdin;
\.
COPY guru (created_on, updated_on, id, youtube_channel_url, facebook_url, twitter_handle, email, name, alias, description, logo_url, headshot_url, meta_association_id) FROM '$$PATH$$/2500.dat';

--
-- Name: guru_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('guru_id_seq', 1, false);


--
-- Data for Name: item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY item (created_on, updated_on, id, name, description, note, meta_association_id) FROM stdin;
\.
COPY item (created_on, updated_on, id, name, description, note, meta_association_id) FROM '$$PATH$$/2498.dat';

--
-- Name: item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('item_id_seq', 1, false);


--
-- Data for Name: maker; Type: TABLE DATA; Schema: public; Owner: -
--

COPY maker (created_on, updated_on, id, nickname, email, role, meta_association_id) FROM stdin;
\.
COPY maker (created_on, updated_on, id, nickname, email, role, meta_association_id) FROM '$$PATH$$/2494.dat';

--
-- Name: maker_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('maker_id_seq', 1, true);


--
-- Data for Name: meta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY meta (created_on, updated_on, id, data, association_id) FROM stdin;
\.
COPY meta (created_on, updated_on, id, data, association_id) FROM '$$PATH$$/2490.dat';

--
-- Data for Name: meta_association; Type: TABLE DATA; Schema: public; Owner: -
--

COPY meta_association (created_on, updated_on, id, discriminator) FROM stdin;
\.
COPY meta_association (created_on, updated_on, id, discriminator) FROM '$$PATH$$/2488.dat';

--
-- Name: meta_association_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('meta_association_id_seq', 128, true);


--
-- Name: meta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('meta_id_seq', 128, true);


--
-- Data for Name: page; Type: TABLE DATA; Schema: public; Owner: -
--

COPY page (created_on, updated_on, id, slug, title, html, meta_association_id) FROM stdin;
\.
COPY page (created_on, updated_on, id, slug, title, html, meta_association_id) FROM '$$PATH$$/2496.dat';

--
-- Name: page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('page_id_seq', 3, true);


--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY product (created_on, updated_on, id, name, description, item_id, price, shop_url, meta_association_id) FROM stdin;
\.
COPY product (created_on, updated_on, id, name, description, item_id, price, shop_url, meta_association_id) FROM '$$PATH$$/2504.dat';

--
-- Name: product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('product_id_seq', 1, false);


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: -
--

COPY project (created_on, updated_on, id, title, description, full_description, maker_id, slug, meta_association_id) FROM stdin;
\.
COPY project (created_on, updated_on, id, title, description, full_description, maker_id, slug, meta_association_id) FROM '$$PATH$$/2502.dat';

--
-- Name: project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('project_id_seq', 1, false);


--
-- Data for Name: related_projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY related_projects (project_id, related_project_id) FROM stdin;
\.
COPY related_projects (project_id, related_project_id) FROM '$$PATH$$/2505.dat';

--
-- Data for Name: resource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY resource (created_on, updated_on, id, project_id, step_id, name, path, meta_association_id) FROM stdin;
\.
COPY resource (created_on, updated_on, id, project_id, step_id, name, path, meta_association_id) FROM '$$PATH$$/2516.dat';

--
-- Name: resource_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('resource_id_seq', 1, false);


--
-- Data for Name: step; Type: TABLE DATA; Schema: public; Owner: -
--

COPY step (created_on, updated_on, id, title, start_time, description, "order", project_id, chapter_id, meta_association_id) FROM stdin;
\.
COPY step (created_on, updated_on, id, title, start_time, description, "order", project_id, chapter_id, meta_association_id) FROM '$$PATH$$/2512.dat';

--
-- Name: step_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('step_id_seq', 1, false);


--
-- Data for Name: tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY tag (created_on, updated_on, id, name, meta_association_id) FROM stdin;
\.
COPY tag (created_on, updated_on, id, name, meta_association_id) FROM '$$PATH$$/2492.dat';

--
-- Name: tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('tag_id_seq', 1, false);


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY tags (tag_id, project_id) FROM stdin;
\.
COPY tags (tag_id, project_id) FROM '$$PATH$$/2508.dat';

--
-- Data for Name: video; Type: TABLE DATA; Schema: public; Owner: -
--

COPY video (created_on, updated_on, id, posted_on, project_id, name, host_guid, path, meta_association_id) FROM stdin;
\.
COPY video (created_on, updated_on, id, posted_on, project_id, name, host_guid, path, meta_association_id) FROM '$$PATH$$/2507.dat';

--
-- Name: video_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('video_id_seq', 128, true);


--
-- Name: chapter_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY chapter
    ADD CONSTRAINT chapter_pkey PRIMARY KEY (id);


--
-- Name: chapter_title_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY chapter
    ADD CONSTRAINT chapter_title_key UNIQUE (title);


--
-- Name: component_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY component
    ADD CONSTRAINT component_pkey PRIMARY KEY (id);


--
-- Name: guru_alias_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY guru
    ADD CONSTRAINT guru_alias_key UNIQUE (alias);


--
-- Name: guru_name_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY guru
    ADD CONSTRAINT guru_name_key UNIQUE (name);


--
-- Name: guru_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY guru
    ADD CONSTRAINT guru_pkey PRIMARY KEY (id);


--
-- Name: item_name_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY item
    ADD CONSTRAINT item_name_key UNIQUE (name);


--
-- Name: item_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY item
    ADD CONSTRAINT item_pkey PRIMARY KEY (id);


--
-- Name: maker_email_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY maker
    ADD CONSTRAINT maker_email_key UNIQUE (email);


--
-- Name: maker_nickname_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY maker
    ADD CONSTRAINT maker_nickname_key UNIQUE (nickname);


--
-- Name: maker_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY maker
    ADD CONSTRAINT maker_pkey PRIMARY KEY (id);


--
-- Name: meta_association_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY meta_association
    ADD CONSTRAINT meta_association_pkey PRIMARY KEY (id);


--
-- Name: meta_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY meta
    ADD CONSTRAINT meta_pkey PRIMARY KEY (id);


--
-- Name: page_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY page
    ADD CONSTRAINT page_pkey PRIMARY KEY (id);


--
-- Name: page_slug_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY page
    ADD CONSTRAINT page_slug_key UNIQUE (slug);


--
-- Name: product_name_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY product
    ADD CONSTRAINT product_name_key UNIQUE (name);


--
-- Name: product_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY product
    ADD CONSTRAINT product_pkey PRIMARY KEY (id);


--
-- Name: project_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: project_slug_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY project
    ADD CONSTRAINT project_slug_key UNIQUE (slug);


--
-- Name: project_title_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY project
    ADD CONSTRAINT project_title_key UNIQUE (title);


--
-- Name: resource_path_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_path_key UNIQUE (path);


--
-- Name: resource_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_pkey PRIMARY KEY (id);


--
-- Name: step_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY step
    ADD CONSTRAINT step_pkey PRIMARY KEY (id);


--
-- Name: step_title_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY step
    ADD CONSTRAINT step_title_key UNIQUE (title);


--
-- Name: tag_name_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tag
    ADD CONSTRAINT tag_name_key UNIQUE (name);


--
-- Name: tag_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tag
    ADD CONSTRAINT tag_pkey PRIMARY KEY (id);


--
-- Name: video_host_guid_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY video
    ADD CONSTRAINT video_host_guid_key UNIQUE (host_guid);


--
-- Name: video_name_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY video
    ADD CONSTRAINT video_name_key UNIQUE (name);


--
-- Name: video_path_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY video
    ADD CONSTRAINT video_path_key UNIQUE (path);


--
-- Name: video_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY video
    ADD CONSTRAINT video_pkey PRIMARY KEY (id);


--
-- Name: chapter_meta_association_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY chapter
    ADD CONSTRAINT chapter_meta_association_id_fkey FOREIGN KEY (meta_association_id) REFERENCES meta_association(id);


--
-- Name: chapter_video_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY chapter
    ADD CONSTRAINT chapter_video_id_fkey FOREIGN KEY (video_id) REFERENCES video(id);


--
-- Name: component_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY component
    ADD CONSTRAINT component_item_id_fkey FOREIGN KEY (item_id) REFERENCES item(id);


--
-- Name: component_meta_association_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY component
    ADD CONSTRAINT component_meta_association_id_fkey FOREIGN KEY (meta_association_id) REFERENCES meta_association(id);


--
-- Name: component_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY component
    ADD CONSTRAINT component_project_id_fkey FOREIGN KEY (project_id) REFERENCES project(id);


--
-- Name: component_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY component
    ADD CONSTRAINT component_step_id_fkey FOREIGN KEY (step_id) REFERENCES step(id);


--
-- Name: guru_meta_association_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY guru
    ADD CONSTRAINT guru_meta_association_id_fkey FOREIGN KEY (meta_association_id) REFERENCES meta_association(id);


--
-- Name: item_meta_association_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY item
    ADD CONSTRAINT item_meta_association_id_fkey FOREIGN KEY (meta_association_id) REFERENCES meta_association(id);


--
-- Name: maker_meta_association_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY maker
    ADD CONSTRAINT maker_meta_association_id_fkey FOREIGN KEY (meta_association_id) REFERENCES meta_association(id);


--
-- Name: meta_association_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY meta
    ADD CONSTRAINT meta_association_id_fkey FOREIGN KEY (association_id) REFERENCES meta_association(id);


--
-- Name: page_meta_association_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY page
    ADD CONSTRAINT page_meta_association_id_fkey FOREIGN KEY (meta_association_id) REFERENCES meta_association(id);


--
-- Name: product_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY product
    ADD CONSTRAINT product_item_id_fkey FOREIGN KEY (item_id) REFERENCES item(id);


--
-- Name: product_meta_association_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY product
    ADD CONSTRAINT product_meta_association_id_fkey FOREIGN KEY (meta_association_id) REFERENCES meta_association(id);


--
-- Name: project_maker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project
    ADD CONSTRAINT project_maker_id_fkey FOREIGN KEY (maker_id) REFERENCES maker(id);


--
-- Name: project_meta_association_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project
    ADD CONSTRAINT project_meta_association_id_fkey FOREIGN KEY (meta_association_id) REFERENCES meta_association(id);


--
-- Name: related_projects_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY related_projects
    ADD CONSTRAINT related_projects_project_id_fkey FOREIGN KEY (project_id) REFERENCES project(id);


--
-- Name: related_projects_related_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY related_projects
    ADD CONSTRAINT related_projects_related_project_id_fkey FOREIGN KEY (related_project_id) REFERENCES project(id);


--
-- Name: resource_meta_association_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_meta_association_id_fkey FOREIGN KEY (meta_association_id) REFERENCES meta_association(id);


--
-- Name: resource_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_project_id_fkey FOREIGN KEY (project_id) REFERENCES project(id);


--
-- Name: resource_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_step_id_fkey FOREIGN KEY (step_id) REFERENCES step(id);


--
-- Name: step_chapter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY step
    ADD CONSTRAINT step_chapter_id_fkey FOREIGN KEY (chapter_id) REFERENCES chapter(id);


--
-- Name: step_meta_association_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY step
    ADD CONSTRAINT step_meta_association_id_fkey FOREIGN KEY (meta_association_id) REFERENCES meta_association(id);


--
-- Name: step_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY step
    ADD CONSTRAINT step_project_id_fkey FOREIGN KEY (project_id) REFERENCES project(id);


--
-- Name: tag_meta_association_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tag
    ADD CONSTRAINT tag_meta_association_id_fkey FOREIGN KEY (meta_association_id) REFERENCES meta_association(id);


--
-- Name: tags_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tags
    ADD CONSTRAINT tags_project_id_fkey FOREIGN KEY (project_id) REFERENCES project(id);


--
-- Name: tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tags
    ADD CONSTRAINT tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES tag(id);


--
-- Name: video_meta_association_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY video
    ADD CONSTRAINT video_meta_association_id_fkey FOREIGN KEY (meta_association_id) REFERENCES meta_association(id);


--
-- Name: video_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY video
    ADD CONSTRAINT video_project_id_fkey FOREIGN KEY (project_id) REFERENCES project(id);


--
-- PostgreSQL database dump complete
--

